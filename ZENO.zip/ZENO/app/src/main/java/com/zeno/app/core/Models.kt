package com.zeno.app.core
import android.graphics.Rect

data class UiNode(val id: Int, val cls: String, val text: String, val desc: String, val viewId: String,
    val clickable: Boolean, val editable: Boolean, val scrollable: Boolean, val checked: Boolean?, val bounds: Rect) {
    val label get() = (text + " " + desc).trim()
}

data class ScreenSnapshot(val pkg: String, val nodes: List<UiNode>, val hasPasswordField: Boolean) {
    fun fingerprint(): Int = nodes.joinToString("|") { "${it.cls}${it.text}${it.desc}${it.checked}" }.hashCode() xor pkg.hashCode()
    fun toPrompt(): String = buildString {
        append("package=$pkg\n")
        nodes.forEach { n ->
            append("[${n.id}] ${n.cls.substringAfterLast('.')}")
            if (n.text.isNotBlank()) append(" text=\"${n.text.take(60)}\"")
            if (n.desc.isNotBlank()) append(" desc=\"${n.desc.take(60)}\"")
            if (n.clickable) append(" clickable"); if (n.editable) append(" editable"); if (n.scrollable) append(" scrollable")
            n.checked?.let { append(" checked=$it") }
            append(" @${n.bounds.centerX()},${n.bounds.centerY()}\n")
        }
    }
}

enum class ActionType { TAP, LONG_PRESS, TYPE, SCROLL, SWIPE, TAP_XY, BACK, OPEN_APP, WAIT, ASK_USER, DONE, FAIL }

data class AgentAction(
    val id: String, val type: ActionType, val targetId: Int? = null, val text: String? = null,
    val x: Int? = null, val y: Int? = null, val x2: Int? = null, val y2: Int? = null,
    val direction: String? = null, val pkg: String? = null,
    val reason: String = "", val expected: String = "", val consequential: Boolean = false,
    val timeoutMs: Long = 3000, val retries: Int = 1
) {
    val needsTarget get() = type in setOf(ActionType.TAP, ActionType.LONG_PRESS, ActionType.TYPE)
    fun describe() = "$type" + (targetId?.let { " #$it" } ?: "") + (text?.let { " \"${it.take(30)}\"" } ?: "") + (pkg?.let { " $it" } ?: "") + " — $reason"
}

enum class TaskStatus { READY, OBSERVING, PLANNING, EXECUTING, VERIFYING, WAITING, PAUSED, COMPLETED, FAILED, CANCELLED }

data class LogLine(val text: String, val verified: Boolean?)

data class TaskUi(
    val status: TaskStatus = TaskStatus.READY, val running: Boolean = false, val paused: Boolean = false,
    val title: String = "", val app: String = "", val step: String = "", val message: String = "",
    val log: List<LogLine> = emptyList(), val actions: Int = 0, val verified: Int = 0, val failed: Int = 0,
    val startMs: Long = 0, val endMs: Long = 0, val confirm: String? = null
)

data class TaskRecord(val id: String, val title: String, val prompt: String, val app: String, val startMs: Long,
    val durationMs: Long, val status: String, val actions: Int, val verified: Int, val failed: Int, val summary: String)

data class Shot(val b64: String, val scale: Float, val w: Int, val h: Int)
