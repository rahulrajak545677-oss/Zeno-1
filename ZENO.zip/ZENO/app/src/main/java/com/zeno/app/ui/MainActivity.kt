package com.zeno.app.ui
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.speech.RecognizerIntent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.zeno.app.ai.Llms
import com.zeno.app.ai.Usage
import com.zeno.app.core.*
import com.zeno.app.data.*
import com.zeno.app.overlay.OrbService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

object Z { val bg = Color(0xFF080A09); val card = Color(0xFF171B17); val elev = Color(0xFF202520); val lime = Color(0xFFC6FF45); val lime2 = Color(0xFF93C42F)
    val text = Color(0xFFF4F6F0); val dim = Color(0xFF9CA49A); val border = Color(0xFF292F29); val warn = Color(0xFFFFC857); val err = Color(0xFFFF5B65) }

class MainActivity : ComponentActivity() {
    val voice = mutableStateOf<String?>(null)
    private val micLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { voice.value = it } }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { launchOrb() }
    fun listen() = runCatching { micLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)) }
    fun openOrb() {
        if (!Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != 0) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else launchOrb()
    }
    private fun launchOrb() = ContextCompat.startForegroundService(this, Intent(this, OrbService::class.java))
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Z.lime, background = Z.bg, surface = Z.card, onPrimary = Z.bg, onBackground = Z.text, onSurface = Z.text)) { Root(this) } } }
}

@Composable fun Root(a: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    var prompt by remember { mutableStateOf(Prefs.instruction) }
    LaunchedEffect(a.voice.value) { a.voice.value?.let { prompt = it; a.voice.value = null } }
    Scaffold(containerColor = Z.bg, bottomBar = {
        NavigationBar(containerColor = Z.card) {
            listOf("Home" to Icons.Default.Home, "Activity" to Icons.Default.List, "Tools" to Icons.Default.Build, "Settings" to Icons.Default.Settings).forEachIndexed { i, (l, ic) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Z.bg, indicatorColor = Z.lime, unselectedIconColor = Z.dim, selectedTextColor = Z.lime, unselectedTextColor = Z.dim)) } } }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            when (tab) { 0 -> Home(a, prompt, { prompt = it }); 1 -> ActivityTab({ prompt = it; tab = 0 }); 2 -> Tools(a, { prompt = it; tab = 0 }); else -> SettingsTab() }
        }
    }
}

@Composable fun Panel(title: String? = null, content: @Composable ColumnScope.() -> Unit) = Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = Z.card), border = BorderStroke(1.dp, Z.border)) {
    Column(Modifier.padding(14.dp)) { title?.let { Text(it, color = Z.text, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(6.dp)) }; content() } }

@Composable fun permState(): Pair<Boolean, Boolean> {
    val ctx = LocalContext.current; var tick by remember { mutableIntStateOf(0) }
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    DisposableEffect(owner) { val o = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) tick++ }; owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) } }
    return remember(tick) { (ZenoAccessibilityService.instance != null) to Settings.canDrawOverlays(ctx) }
}

@Composable fun Home(a: MainActivity, prompt: String, set: (String) -> Unit) {
    val ui by TaskManager.state.collectAsState(); val hist by History.items.collectAsState(); val (a11y, overlay) = permState(); val ctx = LocalContext.current
    var saved by remember { mutableStateOf(false) }
    LazyColumn {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ZENO", color = Z.lime, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("  AI", color = Z.text, fontSize = 26.sp); Spacer(Modifier.weight(1f))
                val (lbl, col) = when { ui.running && ui.paused -> "Paused" to Z.warn; ui.running -> "Working" to Z.lime; !a11y -> "Offline" to Z.err; else -> "Ready" to Z.lime }
                Text("● $lbl", color = col, fontSize = 13.sp)
            }
            Spacer(Modifier.height(18.dp)); Text("Hey, ready?", color = Z.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Tell me what to do. I'll take care of the steps.", color = Z.dim); Spacer(Modifier.height(14.dp))
            OutlinedTextField(prompt, { set(it); saved = false }, Modifier.fillMaxWidth().heightIn(min = 130.dp), placeholder = { Text("Tell ZENO what you want done...", color = Z.dim) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Z.lime, unfocusedBorderColor = Z.border, focusedContainerColor = Z.card, unfocusedContainerColor = Z.card))
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ Prefs.instruction = prompt; History.savePrompt(prompt); saved = true }, enabled = prompt.isNotBlank()) { Text(if (saved) "Saved ✓" else "Save instruction") }
                OutlinedButton({ a.listen() }) { Text("Voice") }; OutlinedButton({ set(""); Prefs.instruction = "" }) { Text("Clear") }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Edit Video" to "Open my video editor and make a cinematic edit: smooth zooms, dark color grading, and a slow-motion intro.",
                    "Photo" to "Enhance this photo: balance exposure, warm the tones, and gently sharpen.", "Automate" to "Repeat the action I set up on this screen for each item in the list.",
                    "Creative" to "Create a clean social media graphic from the template on screen.").forEach { (l, p) -> AssistChip({ set(p) }, { Text(l, fontSize = 12.sp) }) }
            }
            Spacer(Modifier.height(10.dp))
            Panel("Launch") {
                Text("1) Save instruction  2) Open your target app and navigate to the start screen  3) Tap the ZENO orb → START.", color = Z.dim, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp)); Button({ Prefs.instruction = prompt; a.openOrb() }, Modifier.fillMaxWidth()) { Text(if (overlay) "Show ZENO Orb" else "Grant overlay permission") }
                Spacer(Modifier.height(8.dp))
                Text(if (a11y) "✓ Accessibility service on" else "✗ Accessibility service off", color = if (a11y) Z.lime else Z.warn, fontSize = 13.sp)
                if (!a11y) TextButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Open Accessibility settings → ZENO") }
                Text(if (overlay) "✓ Overlay permission granted" else "✗ Overlay permission missing", color = if (overlay) Z.lime else Z.warn, fontSize = 13.sp)
            }
            if (ui.running) Panel("Live task") {
                Text(ui.message.ifBlank { ui.step }, color = Z.dim, fontSize = 12.sp)
                Text("Edit the instruction above, then send it to the running task.", color = Z.dim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ TaskManager.editInstruction(prompt) }) { Text("Send changes") }; OutlinedButton({ Prefs.instruction = prompt; TaskManager.restart() }) { Text("Restart") } } }
            Spacer(Modifier.height(6.dp)); Text("Recent activity", color = Z.text, fontWeight = FontWeight.SemiBold)
            if (hist.isEmpty()) Text("Nothing yet. Finished tasks appear here.", color = Z.dim, fontSize = 13.sp)
        }
        items(hist.take(3)) { r -> RecordCard(r, null, { set(it) }) }
    }
}

@Composable fun RecordCard(r: TaskRecord, onDelete: (() -> Unit)?, reuse: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Panel {
        Row { Text(r.title.ifBlank { "Task" }, color = Z.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(r.status, color = if (r.status == "COMPLETED") Z.lime else Z.warn, fontSize = 12.sp) }
        Text("${r.app} · ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(r.startMs))} · ${r.durationMs / 1000}s", color = Z.dim, fontSize = 12.sp)
        if (open) { Text("Prompt: ${r.prompt}", color = Z.text, fontSize = 12.sp); Text("Actions ${r.actions} · Verified ${r.verified} · Failed ${r.failed}", color = Z.dim, fontSize = 12.sp); Text(r.summary, color = Z.dim, fontSize = 12.sp) }
        Row { TextButton({ open = !open }) { Text(if (open) "Hide" else "Details") }; TextButton({ reuse(r.prompt) }) { Text("Reuse prompt") }; onDelete?.let { TextButton(it) { Text("Delete", color = Z.err) } } }
    }
}

@Composable fun ActivityTab(reuse: (String) -> Unit) {
    val hist by History.items.collectAsState()
    LazyColumn { item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Activity", color = Z.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); if (hist.isNotEmpty()) TextButton({ History.clear() }) { Text("Clear all", color = Z.err) } }
        if (hist.isEmpty()) Text("No tasks yet.", color = Z.dim) }
        items(hist, key = { it.id }) { r -> RecordCard(r, { History.delete(r.id) }, reuse) } }
}

@Composable fun Tools(a: MainActivity, use: (String) -> Unit) {
    val prompts by History.prompts.collectAsState(); val (a11y, overlay) = permState(); val ctx = LocalContext.current
    val templates = listOf("Cinematic edit" to "Edit this video cinematically: smooth zooms, dark color grade, transitions, slow-motion intro.", "Smooth photo enhancement" to "Enhance this photo naturally: exposure, contrast, warmth, light sharpening.",
        "Animate image" to "Animate this image with a subtle zoom and parallax motion.", "Organize files" to "Sort the files in this folder into folders by type. Ask before deleting anything.",
        "Create design" to "Create a minimal poster design using the tools on screen.", "Clean up document" to "Fix spelling and spacing in this document without changing meaning.", "Repetitive task" to "Repeat what is on screen for each item in the list.")
    LazyColumn {
        item { Text("Tools", color = Z.text, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Templates are editable prompts, not macros.", color = Z.dim, fontSize = 13.sp) }
        items(templates) { (n, p) -> Panel(n) { Text(p, color = Z.dim, fontSize = 13.sp); TextButton({ use(p) }) { Text("Use & edit") } } }
        item { Panel("Prompt library") { if (prompts.isEmpty()) Text("Saved instructions appear here.", color = Z.dim, fontSize = 13.sp); prompts.take(8).forEach { p -> TextButton({ use(p) }) { Text(p.take(70), color = Z.text, fontSize = 12.sp) } } }
            Panel("Automation permissions") {
                Text("Accessibility: ${if (a11y) "on" else "off"} — lets ZENO read the screen and tap/type while a task runs.", color = Z.dim, fontSize = 12.sp)
                TextButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Accessibility settings") }
                Text("Overlay: ${if (overlay) "on" else "off"} — shows the orb above other apps.", color = Z.dim, fontSize = 12.sp)
                TextButton({ ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }) { Text("Overlay settings") }
                TextButton({ ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery optimization") } }
            Panel("App compatibility") { Text("ZENO works through the accessibility tree. Apps that draw their UI on a canvas (some editors, games, secure screens) may expose few or no controls; ZENO will tell you and pause instead of guessing. Screenshot/vision fallback is not implemented yet.", color = Z.dim, fontSize = 12.sp) } }
    }
}

@Composable fun SettingsTab() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val (a11y, overlay) = permState()
    var key by remember { mutableStateOf(Prefs.apiKey) }; var model by remember { mutableStateOf(Prefs.model) }
    var delayMs by remember { mutableFloatStateOf(Prefs.actionDelayMs.toFloat()) }; var retries by remember { mutableFloatStateOf(Prefs.maxRetries.toFloat()) }
    var unexp by remember { mutableStateOf(Prefs.pauseOnUnexpected) }; var conf by remember { mutableStateOf(Prefs.confirmConsequential) }
    var size by remember { mutableFloatStateOf(Prefs.orbSizeDp.toFloat()) }; var alpha by remember { mutableFloatStateOf(Prefs.orbAlphaPct.toFloat()) }
    var test by remember { mutableStateOf("") }
    var prov by remember { mutableStateOf(Prefs.provider) }; var base by remember { mutableStateOf(Prefs.baseUrl) }; var vis by remember { mutableStateOf(Prefs.visionEnabled) }; var usage by remember { mutableStateOf(Usage.text()) }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text("Settings", color = Z.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Panel("AI provider") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(prov == "gemini", { prov = "gemini"; Prefs.provider = "gemini" }, { Text("Gemini") }); FilterChip(prov == "openai", { prov = "openai"; Prefs.provider = "openai" }, { Text("OpenAI-compatible") }) }
            if (prov == "openai") OutlinedTextField(base, { base = it; Prefs.baseUrl = it.trim() }, Modifier.fillMaxWidth().padding(top = 6.dp), label = { Text("Base URL") }, singleLine = true)
            OutlinedTextField(key, { key = it; Prefs.apiKey = it }, Modifier.fillMaxWidth(), label = { Text("API key (stored encrypted)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(model, { model = it; Prefs.model = it.trim() }, Modifier.fillMaxWidth().padding(top = 6.dp), label = { Text("Model") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) { Button({ test = "Testing…"; scope.launch { test = runCatching { withContext(Dispatchers.IO) { Llms.create().generate("Reply with JSON {\"ok\":true}", "ping") }; "✓ Connected" }.getOrElse { "✗ ${it.message}" } } }) { Text("Test connection") }; Text("  $test", color = Z.dim, fontSize = 12.sp) }
            Text("Screen text is sent to this provider when a task runs. Password fields are never read.", color = Z.dim, fontSize = 12.sp) }
        Panel("Automation") {
            Text("Action delay: ${delayMs.toInt()} ms", color = Z.text); Slider(delayMs, { delayMs = it; Prefs.actionDelayMs = it.toInt() }, valueRange = 300f..3000f)
            Text("Pause after ${retries.toInt()} failed attempts", color = Z.text); Slider(retries, { retries = it; Prefs.maxRetries = it.toInt() }, valueRange = 1f..6f, steps = 4)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Pause on unexpected screen", color = Z.text, modifier = Modifier.weight(1f)); Switch(unexp, { unexp = it; Prefs.pauseOnUnexpected = it }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Confirm consequential actions", color = Z.text, modifier = Modifier.weight(1f)); Switch(conf, { conf = it; Prefs.confirmConsequential = it }) } }
        Panel("Orb (applies next time it is shown)") {
            Text("Size: ${size.toInt()} dp", color = Z.text); Slider(size, { size = it; Prefs.orbSizeDp = it.toInt() }, valueRange = 40f..80f)
            Text("Opacity: ${alpha.toInt()}%", color = Z.text); Slider(alpha, { alpha = it; Prefs.orbAlphaPct = it.toInt() }, valueRange = 30f..100f)
            Text("Drag the orb to reposition; position is remembered.", color = Z.dim, fontSize = 12.sp) }
        Panel("Vision & usage") {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Screenshot vision fallback", color = Z.text, modifier = Modifier.weight(1f)); Switch(vis, { vis = it; Prefs.visionEnabled = it }) }
            Text("Off by default. When on and a screen exposes no controls, a screenshot is sent to your AI provider. Protected windows cannot be captured. Needs Android 11+.", color = Z.dim, fontSize = 12.sp)
            Text(usage, color = Z.dim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Row { TextButton({ usage = Usage.text() }) { Text("Refresh") }; TextButton({ Usage.reset(); usage = Usage.text() }) { Text("Reset usage") } } }
        Panel("Privacy & system") {
            Text("Accessibility: ${if (a11y) "enabled" else "disabled"}   Overlay: ${if (overlay) "granted" else "missing"}   Screenshots: ${if (vis) "allowed" else "off"}", color = Z.dim, fontSize = 12.sp)
            TextButton({ History.clear() }) { Text("Clear task history", color = Z.err) } }
        Panel("About") { Text("ZENO 0.1.0 — Your AI. Your Apps. Your Actions.", color = Z.dim, fontSize = 12.sp) }
    }
}
