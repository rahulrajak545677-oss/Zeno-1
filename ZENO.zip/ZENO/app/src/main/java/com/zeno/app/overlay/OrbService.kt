package com.zeno.app.overlay
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import com.zeno.app.core.*
import com.zeno.app.data.Prefs
import kotlinx.coroutines.*

class OrbView(c: Context) : View(c) {
    private var st = TaskStatus.READY; private var running = false; private var sweep = 0f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#101310") }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Color.parseColor("#C6FF45") }
    private val spark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#C6FF45") }
    private val anim = android.animation.ValueAnimator.ofFloat(0f, 360f).apply { duration = 1600; repeatCount = -1; interpolator = android.view.animation.LinearInterpolator(); addUpdateListener { sweep = it.animatedValue as Float; invalidate() } }
    fun set(s: TaskStatus, r: Boolean) { st = s; running = r; if (r && s != TaskStatus.PAUSED && s != TaskStatus.WAITING) { if (!anim.isStarted) anim.start() } else anim.cancel(); invalidate() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val cx = w / 2; ring.strokeWidth = w * 0.06f; glyph.strokeWidth = w * 0.07f
        c.drawCircle(cx, cx, cx - 2, bg)
        ring.color = when (st) { TaskStatus.PAUSED, TaskStatus.WAITING -> Color.parseColor("#FFC857"); TaskStatus.FAILED -> Color.parseColor("#FF5B65"); TaskStatus.COMPLETED -> Color.parseColor("#B9F936"); else -> Color.parseColor("#C6FF45") }
        val r = RectF(w * .08f, w * .08f, w * .92f, w * .92f)
        if (running && st != TaskStatus.PAUSED) c.drawArc(r, sweep, 100f, false, ring) else c.drawArc(r, 0f, 360f, false, ring.apply { alpha = 140 }.also { })
        ring.alpha = 255
        c.save(); c.rotate(-28f, cx, cx)       // orbit ellipse
        c.drawOval(RectF(w * .24f, w * .38f, w * .76f, w * .62f), glyph.apply { strokeWidth = w * .04f }); c.restore()
        glyph.strokeWidth = w * .07f                // forward chevron
        val p = Path().apply { moveTo(w * .44f, w * .36f); lineTo(w * .62f, w * .5f); lineTo(w * .44f, w * .64f) }; c.drawPath(p, glyph)
        c.drawCircle(w * .72f, w * .30f, w * .05f, spark)   // spark
    }
}

class OrbService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout; private lateinit var lp: WindowManager.LayoutParams
    private lateinit var orb: OrbView; private lateinit var panel: LinearLayout
    private lateinit var stateTv: TextView; private lateinit var appTv: TextView; private lateinit var instrTv: TextView
    private lateinit var statsTv: TextView; private lateinit var logTv: TextView; private lateinit var confirmTv: TextView
    private lateinit var confirmRow: LinearLayout; private lateinit var bStart: Button; private lateinit var bPause: Button; private lateinit var bResume: Button; private lateinit var bStop: Button
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int { if (i?.action == "STOP_TASK") TaskManager.stop(); return START_NOT_STICKY }
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("orb", "ZENO Orb", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "orb").setContentTitle("ZENO Orb is active").setContentText("Tap the orb to control AutoPilot.").setSmallIcon(android.R.drawable.ic_menu_compass).setOngoing(true).addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop task", PendingIntent.getService(this, 1, Intent(this, OrbService::class.java).setAction("STOP_TASK"), PendingIntent.FLAG_IMMUTABLE)).build()).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        build()
        scope.launch { TaskManager.state.collect { render(it) } }
        scope.launch { while (true) { delay(1000); render(TaskManager.state.value) } }
    }

    private fun tv(t: String, sp: Float, col: String) = TextView(this).apply { text = t; textSize = sp; setTextColor(Color.parseColor(col)) }
    private fun btn(t: String, col: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; setTextColor(Color.parseColor("#080A09")); isAllCaps = false; minHeight = 0; minimumHeight = 0
        background = GradientDrawable().apply { setColor(Color.parseColor(col)); cornerRadius = 20f.dp() }
        layoutParams = LinearLayout.LayoutParams(0, 38.dp(), 1f).apply { setMargins(3.dp(), 0, 3.dp(), 0) }; setOnClickListener { f() }
    }

    private fun build() {
        val size = Prefs.orbSizeDp.dp()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; alpha = Prefs.orbAlphaPct / 100f }
        orb = OrbView(this).apply { layoutParams = LinearLayout.LayoutParams(size, size) }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp()); visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#F2101310")); cornerRadius = 18f.dp(); setStroke(1.dp(), Color.parseColor("#292F29")) }
            layoutParams = LinearLayout.LayoutParams(300.dp(), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 6.dp() }
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(tv("ZENO AI", 15f, "#F4F6F0").apply { setTypeface(typeface, Typeface.BOLD); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        head.addView(tv("Minimize", 12f, "#9CA49A").apply { setPadding(8.dp(), 0, 8.dp(), 0); setOnClickListener { panel.visibility = View.GONE } })
        head.addView(tv("Close", 12f, "#FF5B65").apply { setOnClickListener { stopSelf() } })
        stateTv = tv("", 13f, "#C6FF45"); appTv = tv("", 12f, "#9CA49A"); instrTv = tv("", 12f, "#F4F6F0").apply { maxLines = 3; setPadding(0, 6.dp(), 0, 6.dp()) }
        val modes = tv("Vision: accessibility tree  ·  AutoPilot  ·  Smart Control: semantic actions", 10f, "#93C42F")
        statsTv = tv("", 11f, "#9CA49A").apply { setPadding(0, 6.dp(), 0, 4.dp()) }
        logTv = tv("", 11f, "#F4F6F0")
        confirmTv = tv("", 12f, "#FFC857")
        confirmRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(0, 8.dp(), 0, 0) }
        val cb = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cb.addView(btn("Allow", "#C6FF45") { TaskManager.answerConfirm(true) }); cb.addView(btn("Deny", "#FF5B65") { TaskManager.answerConfirm(false) })
        confirmRow.addView(confirmTv); confirmRow.addView(cb)
        val ctl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8.dp(), 0, 0) }
        bStart = btn("START", "#C6FF45") { TaskManager.start() }; bPause = btn("PAUSE", "#FFC857") { TaskManager.pause() }
        bResume = btn("RESUME", "#C6FF45") { TaskManager.resume() }; bStop = btn("STOP", "#FF5B65") { TaskManager.stop() }
        listOf(bStart, bPause, bResume, bStop).forEach { ctl.addView(it) }
        listOf(head, stateTv, appTv, instrTv, modes, statsTv, logTv, confirmRow, ctl).forEach { panel.addView(it) }
        root.addView(orb); root.addView(panel)
        lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = Prefs.orbX; y = Prefs.orbY }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        orb.setOnTouchListener { _, e -> when (e.action) {
            MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false; true }
            MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - dx) + Math.abs(e.rawY - dy) > 12) moved = true
                if (moved) { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(root, lp) }; true }
            MotionEvent.ACTION_UP -> { if (moved) { Prefs.orbX = lp.x; Prefs.orbY = lp.y } else panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE; true }
            else -> false } }
        wm.addView(root, lp); render(TaskManager.state.value)
    }

    private fun render(s: TaskUi) {
        orb.set(s.status, s.running)
        stateTv.text = "ZENO is ${s.status.name.lowercase()}" + if (s.step.isNotBlank() && s.running) " — ${s.step.take(60)}" else ""
        appTv.text = "Current app: ${s.app.ifBlank { "—" }}   Task: ${s.title.ifBlank { "—" }}"
        instrTv.text = Prefs.instruction.ifBlank { "No instruction saved — write one in ZENO." }
        val end = if (s.running) System.currentTimeMillis() else s.endMs; val el = if (s.startMs > 0) (end - s.startMs) / 1000 else 0
        statsTv.text = "Actions ${s.actions} · Verified ${s.verified} · Failed ${s.failed} · ${el / 60}:${(el % 60).toString().padStart(2, '0')}"
        logTv.text = s.log.takeLast(8).joinToString("\n") { (when (it.verified) { true -> "✓ "; false -> "✗ "; null -> "• " }) + it.text.take(90) }
        confirmRow.visibility = if (s.confirm != null) View.VISIBLE else View.GONE; confirmTv.text = "Confirm: ${s.confirm}"
        bStart.visibility = if (!s.running) View.VISIBLE else View.GONE
        bPause.visibility = if (s.running && !s.paused) View.VISIBLE else View.GONE
        bResume.visibility = if (s.running && s.paused) View.VISIBLE else View.GONE
        bStop.visibility = if (s.running) View.VISIBLE else View.GONE
    }
    override fun onDestroy() { scope.cancel(); if (::root.isInitialized) runCatching { wm.removeView(root) }; super.onDestroy() }
}
