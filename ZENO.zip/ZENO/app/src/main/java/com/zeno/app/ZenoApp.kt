package com.zeno.app
import android.app.Application
import com.zeno.app.core.TaskManager
import com.zeno.app.data.History
import com.zeno.app.data.Prefs
class ZenoApp : Application() {
    override fun onCreate() { super.onCreate(); Prefs.init(this); History.init(); TaskManager.init(this) }
}
