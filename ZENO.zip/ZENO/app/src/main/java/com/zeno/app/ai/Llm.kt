package com.zeno.app.ai
import com.zeno.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class LlmException(msg: String) : Exception(msg)

/** Provider-agnostic interface. images are JPEG base64. */
interface LlmClient { suspend fun generate(system: String, user: String, imageB64Png: String? = null): String }

object Usage {
    fun add(i: Int, o: Int) { val s = Prefs.raw(); s.edit().putInt("u_req", s.getInt("u_req", 0) + 1).putLong("u_in", s.getLong("u_in", 0) + i).putLong("u_out", s.getLong("u_out", 0) + o).apply() }
    fun reset() { Prefs.raw().edit().remove("u_req").remove("u_in").remove("u_out").apply() }
    fun text(): String { val s = Prefs.raw(); return "${s.getInt("u_req", 0)} requests · ${s.getLong("u_in", 0)} input tokens · ${s.getLong("u_out", 0)} output tokens (as reported by the provider)" }
}

private suspend fun postJson(url: String, headers: Map<String, String>, body: String): String = withContext(Dispatchers.IO) {
    var last = "unknown error"
    repeat(3) { attempt ->
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 45000; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json"); headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code in 200..299) return@withContext txt
            last = "HTTP $code: ${txt.take(200)}"
            if (code != 429 && code < 500) throw LlmException(last)
        } catch (e: LlmException) { throw e } catch (e: Exception) { last = e.message ?: e.javaClass.simpleName }
        delay(800L * (attempt + 1))
    }
    throw LlmException("AI request failed: $last")
}

class GeminiClient(private val apiKey: String, private val model: String) : LlmClient {
    override suspend fun generate(system: String, user: String, imageB64Png: String?): String {
        if (apiKey.isBlank()) throw LlmException("No API key configured (Settings → AI).")
        val parts = JSONArray().put(JSONObject().put("text", user))
        if (imageB64Png != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", imageB64Png)))
        val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.2)).toString()
        val r = JSONObject(postJson("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", mapOf("x-goog-api-key" to apiKey), body))
        r.optJSONObject("usageMetadata")?.let { Usage.add(it.optInt("promptTokenCount"), it.optInt("candidatesTokenCount")) }
        return r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}

/** Any OpenAI-compatible /chat/completions endpoint (OpenAI, OpenRouter, local servers…). */
class OpenAiCompatClient(private val baseUrl: String, private val apiKey: String, private val model: String) : LlmClient {
    override suspend fun generate(system: String, user: String, imageB64Png: String?): String {
        if (apiKey.isBlank()) throw LlmException("No API key configured (Settings → AI).")
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", user))
        if (imageB64Png != null) content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imageB64Png")))
        val body = JSONObject().put("model", model).put("temperature", 0.2).put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", system)).put(JSONObject().put("role", "user").put("content", content))).toString()
        val r = JSONObject(postJson(baseUrl.trimEnd('/') + "/chat/completions", mapOf("Authorization" to "Bearer $apiKey"), body))
        r.optJSONObject("usage")?.let { Usage.add(it.optInt("prompt_tokens"), it.optInt("completion_tokens")) }
        return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}

object Llms { fun create(): LlmClient = if (Prefs.provider == "openai") OpenAiCompatClient(Prefs.baseUrl, Prefs.apiKey, Prefs.model) else GeminiClient(Prefs.apiKey, Prefs.model) }

object Json {
    fun obj(s: String): JSONObject {
        val t = s.trim(); val i = t.indexOf('{'); val j = t.lastIndexOf('}')
        if (i < 0 || j < i) throw LlmException("Model did not return JSON")
        return JSONObject(t.substring(i, j + 1))
    }
}
