package com.zeno.app.core
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.util.Base64
import android.view.Display
import java.io.ByteArrayOutputStream
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** ZENO Vision (accessibility layer) + semantic action executor. */
class ZenoAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: ZenoAccessibilityService? = null }
    private var refs: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun snapshot(): ScreenSnapshot? {
        val root = rootInActiveWindow ?: return null
        val out = ArrayList<UiNode>(); val rs = ArrayList<AccessibilityNodeInfo>(); var pw = false
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (out.size >= 150 || depth > 30) return
            if (n.isVisibleToUser) {
                if (n.isPassword) pw = true
                val text = if (n.isPassword) "" else n.text?.toString().orEmpty()
                val desc = if (n.isPassword) "password field (hidden)" else n.contentDescription?.toString().orEmpty()
                if (text.isNotBlank() || desc.isNotBlank() || n.isClickable || n.isEditable || n.isScrollable) {
                    val b = Rect(); n.getBoundsInScreen(b)
                    out.add(UiNode(out.size, n.className?.toString().orEmpty(), text, desc, n.viewIdResourceName.orEmpty(),
                        n.isClickable, n.isEditable, n.isScrollable, if (n.isCheckable) n.isChecked else null, b))
                    rs.add(n)
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0); refs = rs
        return ScreenSnapshot(root.packageName?.toString().orEmpty(), out, pw)
    }

    /** Vision fallback (API 30+). Fails on FLAG_SECURE windows, which is the right behaviour. */
    suspend fun screenshot(): Shot? {
        if (Build.VERSION.SDK_INT < 30) return null
        return suspendCancellableCoroutine { c ->
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    val bmp = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    r.hardwareBuffer.close()
                    if (bmp == null) { if (c.isActive) c.resume(null); return }
                    val sc = minOf(1f, 1000f / bmp.width)
                    val sm = if (sc < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true) else bmp
                    val out = ByteArrayOutputStream(); sm.compress(Bitmap.CompressFormat.JPEG, 70, out)
                    if (c.isActive) c.resume(Shot(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), sc, sm.width, sm.height))
                }
                override fun onFailure(code: Int) { if (c.isActive) c.resume(null) }
            })
        }
    }

    private fun node(id: Int?) = id?.let { refs.getOrNull(it) }
    private fun clickable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? { var c = n; while (c != null && !c.isClickable) c = c.parent; return c }

    /** Returns true if Android accepted the action. Verification is done separately by SelfCheck. */
    suspend fun perform(a: AgentAction): Boolean = when (a.type) {
        ActionType.TAP -> { val n = node(a.targetId); val c = clickable(n)
            if (c != null) c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            else if (n != null) { val b = Rect(); n.getBoundsInScreen(b); gesture(b.centerX().toFloat(), b.centerY().toFloat(), b.centerX().toFloat(), b.centerY().toFloat(), 50) } else false }
        ActionType.LONG_PRESS -> { val n = node(a.targetId); val c = clickable(n)
            if (c != null) c.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
            else if (n != null) { val b = Rect(); n.getBoundsInScreen(b); gesture(b.centerX().toFloat(), b.centerY().toFloat(), b.centerX().toFloat(), b.centerY().toFloat(), 700) } else false }
        ActionType.TYPE -> { val n = node(a.targetId)
            if (n == null || !n.isEditable || n.isPassword) false else {
                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.text.orEmpty()) }) } }
        ActionType.SCROLL -> { val n = node(a.targetId)?.takeIf { it.isScrollable } ?: refs.firstOrNull { it.isScrollable }
            val fwd = a.direction?.lowercase() in setOf("down", "forward", "right")
            n?.performAction(if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false }
        ActionType.SWIPE -> if (a.x != null && a.y != null && a.x2 != null && a.y2 != null) gesture(a.x.toFloat(), a.y.toFloat(), a.x2.toFloat(), a.y2.toFloat(), 350) else false
        ActionType.TAP_XY -> if (a.x != null && a.y != null) gesture(a.x.toFloat(), a.y.toFloat(), a.x.toFloat(), a.y.toFloat(), 50) else false
        ActionType.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
        ActionType.OPEN_APP -> a.pkg?.takeIf { it != packageName }?.let { p ->
            packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } } ?: false
        ActionType.WAIT -> { delay(a.timeoutMs.coerceIn(200, 10000)); true }
        else -> false
    }

    private suspend fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean = suspendCancellableCoroutine { c ->
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(false) }
        }, null)
        if (!ok && c.isActive) c.resume(false)
    }
}
