package com.zeno.app.core
import android.content.Context
import com.zeno.app.ai.*
import com.zeno.app.data.History
import com.zeno.app.data.Prefs
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

/** Perception → planning → action → verification loop. All UI state comes from here. */
object TaskManager {
    val state = MutableStateFlow(TaskUi())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val paused = MutableStateFlow(false)
    private var confirmReply: CompletableDeferred<Boolean>? = null
    private lateinit var ctx: Context
    fun init(c: Context) { ctx = c.applicationContext }

    private fun upd(f: (TaskUi) -> TaskUi) = state.update(f)
    private fun log(t: String, v: Boolean? = null) = upd { it.copy(log = (it.log + LogLine(t, v)).takeLast(80)) }
    private fun status(s: TaskStatus, step: String = state.value.step) = upd { it.copy(status = s, step = step) }

    fun start() {
        if (job?.isActive == true) return
        val instr = Prefs.instruction.trim()
        val problem = when {
            instr.isBlank() -> "No instruction saved. Write one in ZENO first."
            Prefs.apiKey.isBlank() -> "No API key. Add one in ZENO → Settings → AI."
            ZenoAccessibilityService.instance == null -> "Accessibility service is off. Enable it in Android settings."
            else -> null
        }
        if (problem != null) { upd { it.copy(status = TaskStatus.FAILED, running = false, message = problem, log = it.log + LogLine(problem, false)) }; return }
        paused.value = false; liveInstr = instr
        state.value = TaskUi(status = TaskStatus.OBSERVING, running = true, title = instr.take(48), startMs = System.currentTimeMillis())
        job = scope.launch {
            try { run(instr) }
            catch (e: CancellationException) { finish(TaskStatus.CANCELLED, "Stopped by user") }
            catch (e: Exception) { finish(TaskStatus.FAILED, e.message ?: e.javaClass.simpleName) }
        }
    }
    fun pause() { if (state.value.running) { paused.value = true; upd { it.copy(status = TaskStatus.PAUSED, paused = true) }; log("Paused — no new actions will be issued") } }
    fun resume() { if (state.value.running && paused.value) { paused.value = false; upd { it.copy(status = TaskStatus.OBSERVING, paused = false) }; log("Resumed — re-observing screen") } }
    @Volatile private var liveInstr = ""
    /** Change the goal mid-task; the next loop iteration replans. */
    fun editInstruction(text: String) { if (state.value.running && text.isNotBlank() && text != liveInstr) { liveInstr = text; Prefs.instruction = text; log("Instruction updated — replanning") } }
    fun restart() { scope.launch { job?.cancelAndJoin(); start() } }
    fun stop() { job?.cancel(); confirmReply?.complete(false) }
    fun answerConfirm(ok: Boolean) { confirmReply?.complete(ok) }

    private suspend fun gatePause() { if (paused.value) paused.first { !it } }
    private suspend fun awaitUser(msg: String) { log(msg); upd { it.copy(message = msg, status = TaskStatus.PAUSED, paused = true) }; paused.value = true; gatePause() }
    private suspend fun askConfirm(msg: String): Boolean {
        val d = CompletableDeferred<Boolean>(); confirmReply = d
        upd { it.copy(status = TaskStatus.WAITING, confirm = msg) }; log("Waiting for your confirmation: $msg")
        val r = d.await(); upd { it.copy(confirm = null) }; return r
    }
    private suspend fun observe(): ScreenSnapshot? {
        repeat(3) { ZenoAccessibilityService.instance?.snapshot()?.takeIf { s -> s.pkg.isNotEmpty() }?.let { return it }; delay(400) }
        return null
    }
    private fun label(pkg: String) = runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)

    private fun finish(s: TaskStatus, summary: String) {
        val now = System.currentTimeMillis(); val u = state.value
        upd { it.copy(status = s, running = false, paused = false, endMs = now, message = summary, confirm = null) }
        log(summary, s == TaskStatus.COMPLETED)
        History.add(TaskRecord("t$now", u.title, Prefs.instruction, u.app, u.startMs, now - u.startMs, s.name, u.actions, u.verified, u.failed, summary))
    }

    private suspend fun run(instr: String) {
        val llm = Llms.create()
        val planner = NeuralPlan(llm); val gen = ActionGenerator(llm); val check = SelfCheck(llm)
        var snap = observe() ?: error("Cannot read the screen (accessibility unavailable).")
        if (snap.pkg == ctx.packageName) error("Open the app you want ZENO to operate first, then press START.")
        var target = snap.pkg
        upd { it.copy(app = label(target)) }; log("Identified app: ${label(target)}", true)
        status(TaskStatus.PLANNING, "Planning")
        val planRaw = planner.plan(instr, snap)
        planRaw.firstOrNull { it.startsWith("TITLE:") }?.let { t -> upd { it.copy(title = t.removePrefix("TITLE:")) } }
        var plan = planRaw.filter { !it.startsWith("TITLE:") }; var goal = instr
        log("Plan ready (${plan.size} steps, adaptive)", true)
        val hist = mutableListOf<String>(); var fails = 0; var n = 0; val sigs = ArrayDeque<String>()

        while (n < Prefs.maxSteps) {
            gatePause()
            status(TaskStatus.OBSERVING, "Reading screen")
            snap = observe() ?: error("Lost access to the screen (permission revoked or app blocked it).")
            if (snap.hasPasswordField) { awaitUser("Sign-in/credential screen detected. ZENO won't operate it — finish it yourself, then press RESUME."); target = observe()?.pkg ?: target; continue }
            if (snap.pkg != target && Prefs.pauseOnUnexpected) { awaitUser("Unexpected app on screen (${label(snap.pkg)}). Go back to your task, then press RESUME."); target = observe()?.pkg ?: target; upd { it.copy(app = label(target)) }; continue }
            if (SafetyGate.blockedPackage(snap.pkg)) { finish(TaskStatus.FAILED, "ZENO won't operate banking, payment, password-manager or system permission apps (${snap.pkg})."); return }
            if (liveInstr != goal) { goal = liveInstr; status(TaskStatus.PLANNING, "Replanning")
                planner.plan(goal, snap).let { p -> p.firstOrNull { it.startsWith("TITLE:") }?.let { t -> upd { it.copy(title = t.removePrefix("TITLE:")) } }; plan = p.filter { !it.startsWith("TITLE:") } }
                hist += "User changed the instruction to: $goal" }
            var shot: Shot? = null
            if (snap.nodes.size < 2) {
                if (Prefs.visionEnabled) shot = ZenoAccessibilityService.instance?.screenshot()
                if (shot == null) { awaitUser(if (!Prefs.visionEnabled) "This screen exposes almost no accessible controls. Turn on screenshot vision in Settings, or navigate manually, then RESUME." else "Couldn't capture this screen (protected or unsupported). Navigate manually, then RESUME."); continue }
                log("Few accessible controls — using screenshot vision", null)
            }

            n++; status(TaskStatus.PLANNING, "Step $n: deciding")
            val a = gen.next(goal, plan, snap, hist, n, shot)
            when (a.type) {
                ActionType.DONE -> { val (ok, note) = check.goalDone(goal, snap)
                    if (ok) { finish(TaskStatus.COMPLETED, "Goal verified on screen. $note"); return }
                    hist += "DONE rejected by Self-Check: $note"; log("Not finished yet: $note", false); continue }
                ActionType.FAIL -> { finish(TaskStatus.FAILED, a.reason); return }
                ActionType.ASK_USER -> { awaitUser(a.reason); continue }
                else -> {}
            }
            if (a.needsTarget && (a.targetId == null || a.targetId !in snap.nodes.indices)) {
                fails++; upd { it.copy(failed = it.failed + 1) }; hist += "step $n: invalid target for ${a.type}"; log("Model chose an invalid target; re-planning", false)
                if (fails >= Prefs.maxRetries) { awaitUser("ZENO is stuck. Please help, then RESUME."); fails = 0 }; continue
            }
            if (Prefs.confirmConsequential && SafetyGate.needsConfirmation(a, snap) && !askConfirm(a.describe())) {
                hist += "step $n: user DENIED ${a.type}"; log("You declined: ${a.describe()}"); continue
            }
            val sig = "${a.type}${a.targetId}${a.text}${a.x}${a.y}${snap.fingerprint()}"; sigs.addLast(sig); if (sigs.size > 3) sigs.removeFirst()
            if (sigs.size == 3 && sigs.all { it == sig }) { sigs.clear(); awaitUser("ZENO is repeating the same action with no change. Please help, then RESUME."); continue }
            gatePause()   // honour a pause requested while the model was thinking
            status(TaskStatus.EXECUTING, a.describe()); log(a.describe())
            upd { it.copy(actions = it.actions + 1) }
            val exec = if (shot != null) a.copy(x = a.x?.let { (it / shot.scale).toInt() }, y = a.y?.let { (it / shot.scale).toInt() }, x2 = a.x2?.let { (it / shot.scale).toInt() }, y2 = a.y2?.let { (it / shot.scale).toInt() }) else a
            val accepted = withTimeoutOrNull(a.timeoutMs + 8000) { withContext(Dispatchers.Main) { ZenoAccessibilityService.instance?.perform(exec) ?: false } } ?: false
            if (a.type == ActionType.WAIT) { hist += "step $n: waited"; continue }
            delay(Prefs.actionDelayMs.toLong())
            status(TaskStatus.VERIFYING, "Self-Check")
            val after = observe()
            val afterShot = if (shot != null) ZenoAccessibilityService.instance?.screenshot() else null
            val (ok, note) = if (!accepted) false to "Android rejected the action" else check.verify(a, snap, after, afterShot)
            if (ok) { upd { it.copy(verified = it.verified + 1) }; log("Verified: ${a.expected.take(60)}", true); fails = 0
                if (a.type == ActionType.OPEN_APP && after != null) { target = after.pkg; upd { it.copy(app = label(target)) } } }
            else { upd { it.copy(failed = it.failed + 1) }; fails++; log("Not verified: $note", false) }
            hist += "step $n: ${a.describe()} -> ${if (ok) "verified" else "FAILED ($note)"}"
            if (fails >= Prefs.maxRetries) { awaitUser("$fails attempts in a row failed. Please check the screen, then RESUME."); fails = 0 }
        }
        finish(TaskStatus.FAILED, "Step limit (${Prefs.maxSteps}) reached without a verified result.")
    }
}
