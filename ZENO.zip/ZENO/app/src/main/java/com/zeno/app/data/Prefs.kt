package com.zeno.app.data
import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.zeno.app.core.TaskRecord
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private lateinit var sp: SharedPreferences
    private lateinit var secure: SharedPreferences
    fun init(c: Context) {
        sp = c.getSharedPreferences("zeno", 0)
        val mk = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        secure = EncryptedSharedPreferences.create(c, "zeno_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    var apiKey: String get() = secure.getString("key", "")!! ; set(v) = secure.edit().putString("key", v).apply()
    var model: String get() = sp.getString("model", "gemini-2.5-flash")!! ; set(v) = sp.edit().putString("model", v).apply()
    var provider: String get() = sp.getString("prov", "gemini")!! ; set(v) = sp.edit().putString("prov", v).apply()
    var baseUrl: String get() = sp.getString("base", "https://api.openai.com/v1")!! ; set(v) = sp.edit().putString("base", v).apply()
    var visionEnabled: Boolean get() = sp.getBoolean("vision", false) ; set(v) = sp.edit().putBoolean("vision", v).apply()
    var instruction: String get() = sp.getString("instr", "")!! ; set(v) = sp.edit().putString("instr", v).apply()
    var actionDelayMs: Int get() = sp.getInt("delay", 900) ; set(v) = sp.edit().putInt("delay", v).apply()
    var maxRetries: Int get() = sp.getInt("retries", 3) ; set(v) = sp.edit().putInt("retries", v).apply()
    var maxSteps: Int get() = sp.getInt("steps", 40) ; set(v) = sp.edit().putInt("steps", v).apply()
    var pauseOnUnexpected: Boolean get() = sp.getBoolean("unexp", true) ; set(v) = sp.edit().putBoolean("unexp", v).apply()
    var confirmConsequential: Boolean get() = sp.getBoolean("confirm", true) ; set(v) = sp.edit().putBoolean("confirm", v).apply()
    var orbSizeDp: Int get() = sp.getInt("orbSize", 56) ; set(v) = sp.edit().putInt("orbSize", v).apply()
    var orbAlphaPct: Int get() = sp.getInt("orbAlpha", 100) ; set(v) = sp.edit().putInt("orbAlpha", v).apply()
    var orbX: Int get() = sp.getInt("ox", 24) ; set(v) = sp.edit().putInt("ox", v).apply()
    var orbY: Int get() = sp.getInt("oy", 400) ; set(v) = sp.edit().putInt("oy", v).apply()
    fun raw() = sp
}

object History {
    val items = MutableStateFlow<List<TaskRecord>>(emptyList())
    val prompts = MutableStateFlow<List<String>>(emptyList())
    fun init() {
        val a = JSONArray(Prefs.raw().getString("history", "[]"))
        items.value = (0 until a.length()).map { val o = a.getJSONObject(it)
            TaskRecord(o.getString("id"), o.getString("title"), o.getString("prompt"), o.getString("app"), o.getLong("start"), o.getLong("dur"),
                o.getString("status"), o.getInt("actions"), o.getInt("verified"), o.getInt("failed"), o.getString("summary")) }
        val p = JSONArray(Prefs.raw().getString("prompts", "[]")); prompts.value = (0 until p.length()).map { p.getString(it) }
    }
    private fun persist() {
        val a = JSONArray(); items.value.forEach { r -> a.put(JSONObject().put("id", r.id).put("title", r.title).put("prompt", r.prompt).put("app", r.app)
            .put("start", r.startMs).put("dur", r.durationMs).put("status", r.status).put("actions", r.actions).put("verified", r.verified).put("failed", r.failed).put("summary", r.summary)) }
        Prefs.raw().edit().putString("history", a.toString()).putString("prompts", JSONArray(prompts.value).toString()).apply()
    }
    fun add(r: TaskRecord) { items.value = (listOf(r) + items.value).take(200); persist() }
    fun delete(id: String) { items.value = items.value.filter { it.id != id }; persist() }
    fun clear() { items.value = emptyList(); persist() }
    fun savePrompt(p: String) { if (p.isNotBlank()) { prompts.value = (listOf(p) + prompts.value.filter { it != p }).take(30); persist() } }
}
