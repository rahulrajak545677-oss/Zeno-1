package com.zeno.app.core
object SafetyGate {
    private val risky = Regex("\\b(delete|remove|erase|send|post|publish|share|upload|buy|purchase|pay|checkout|order|subscribe|confirm payment|sign out|log out|uninstall|reset|factory|format|password|security|transfer)\\b", RegexOption.IGNORE_CASE)
    private val blocked = Regex("(bank|paypal|wallet|authenticator|keepass|bitwarden|lastpass|1password|payment|packageinstaller|permissioncontroller)", RegexOption.IGNORE_CASE)
    /** ZENO refuses to operate banking, payment, password-manager and permission/installer apps. */
    fun blockedPackage(pkg: String) = blocked.containsMatchIn(pkg)
    fun looksConsequential(label: String) = risky.containsMatchIn(label)
    fun needsConfirmation(a: AgentAction, snap: ScreenSnapshot): Boolean {
        if (a.consequential) return true
        val label = a.targetId?.let { snap.nodes.getOrNull(it)?.label }.orEmpty()
        return looksConsequential(label)
    }
}
