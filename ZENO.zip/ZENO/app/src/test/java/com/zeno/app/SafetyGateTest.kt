package com.zeno.app
import com.zeno.app.core.SafetyGate
import org.junit.Assert.*
import org.junit.Test
class SafetyGateTest {
    @Test fun flagsRisky() { assertTrue(SafetyGate.looksConsequential("Delete project")); assertTrue(SafetyGate.looksConsequential("Publish")); assertTrue(SafetyGate.looksConsequential("Pay now")) }
    @Test fun blocksSensitiveApps() { assertTrue(SafetyGate.blockedPackage("com.example.mybank")); assertTrue(SafetyGate.blockedPackage("com.x.authenticator")); assertFalse(SafetyGate.blockedPackage("com.lemon.lvoverseas")) }
    @Test fun allowsNormal() { assertFalse(SafetyGate.looksConsequential("Add transition")); assertFalse(SafetyGate.looksConsequential("Color")) }
}
