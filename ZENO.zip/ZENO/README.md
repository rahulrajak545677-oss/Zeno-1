# ZENO — Your AI. Your Apps. Your Actions.
Android AI operator: Accessibility-tree perception → Gemini planning → semantic actions → Self-Check verification.

## Build
Open in Android Studio (Koala+), sync, run on a device (API 26+). Then:
1. Settings → paste Gemini API key → Test connection.
2. Home → Show ZENO Orb (grant overlay). Enable ZENO in Android Accessibility settings.
3. Save an instruction, open the target app, tap the orb → START.

## Status (honest)
Implemented, NOT yet compiled or device-tested: Compose app (Home/Activity/Tools/Settings), orb overlay (drag, persist position, panel, START/PAUSE/RESUME/STOP, confirm Allow/Deny), accessibility snapshot + executor (tap/long-press/type/scroll/swipe/back/open app/wait), Gemini client (retry, timeout), NeuralPlan / ActionGenerator / SelfCheck, SafetyGate, pause-on-unexpected-screen, credential-screen refusal, history persistence.
Added in v0.1.1 (also uncompiled): screenshot vision fallback (accessibility takeScreenshot, Android 11+, opt-in), edit-while-running + restart, OpenAI-compatible provider, token usage display, stuck-loop guard, blocked sensitive apps (banking/payment/password managers), "Stop task" notification action.
Not implemented: MediaProjection, Room (history uses SharedPreferences JSON), animation polish, instrumentation tests.
